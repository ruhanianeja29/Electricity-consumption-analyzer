// Home Energy Analytics - C++17 backend + HTML frontend
// Single file, no external libraries. Works on Windows, macOS, Linux and Termux.
//
// Build:  clang++ -std=c++17 main.cpp -o home_energy        (Windows/MinGW: add -lws2_32)
// Run  :  run the program, then open the address it prints.

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <map>
#include <algorithm>
#include <iomanip>
#include <ctime>
#include <cctype>
#include <cstdlib>
#include <cmath>
#include <cstdint>
#include <random>
#include <filesystem>
#include <csignal>

#ifdef _WIN32
  #ifndef NOMINMAX
  #define NOMINMAX
  #endif
  #include <winsock2.h>
  #include <ws2tcpip.h>
  #include <shellapi.h>
  #pragma comment(lib, "ws2_32.lib")
  typedef SOCKET sock_t;
  #define CLOSESOCK closesocket
  #define BAD_SOCK INVALID_SOCKET
#else
  #include <sys/types.h>
  #include <sys/socket.h>
  #include <netinet/in.h>
  #include <arpa/inet.h>
  #include <unistd.h>
  #include <sys/time.h>
  #include <sys/wait.h>
  typedef int sock_t;
  #define CLOSESOCK close
  #define BAD_SOCK (-1)
#endif

using namespace std;
namespace fs = std::filesystem;

// ----------------------------------------------------------------- data types
struct Appliance { int id; string name; string category; int watts; int standby; string efficiency; string priority; string status; };
struct Usage     { int id; string date; string name; double hours; int watts; double daily; };
struct UserData  { vector<Appliance> custom; vector<Usage> usages; bool solar = false; int nextId = 1; };

const double TARIFF = 8.0;

// Predefined basic appliances - always available to every user.
const vector<Appliance> DEFAULT_APPLIANCES = {
 {1,"Air Conditioner","Cooling",1500,2,"B","Essential","ON"},{2,"Ceiling Fan","Cooling",75,1,"A","Essential","ON"},
 {3,"Refrigerator","Kitchen",200,5,"B","Essential","ON"},{4,"Washing Machine","Laundry",500,1,"B","Normal","ON"},
 {5,"LED Bulb","Lighting",9,1,"B","Normal","ON"},{6,"Tube Light","Lighting",40,1,"B","Normal","ON"},
 {7,"Television","Entertainment",100,1,"B","Normal","ON"},{8,"Laptop","Electronics",65,1,"B","Normal","ON"},
 {9,"Desktop Computer","Electronics",200,1,"B","Normal","ON"},{10,"Water Heater / Geyser","Heating",2000,1,"B","Normal","ON"},
 {11,"Water Pump","Utility",750,1,"B","Normal","ON"},{12,"Microwave Oven","Kitchen",1200,1,"B","Normal","ON"},
 {13,"Electric Iron","Utility",1000,1,"B","Normal","ON"},{14,"Mixer Grinder","Kitchen",500,1,"B","Normal","ON"},
 {15,"Electric Kettle","Kitchen",1500,1,"B","Normal","ON"},{16,"Cooler","Cooling",180,1,"B","Normal","ON"},
 {17,"Room Heater","Heating",1500,1,"B","Normal","ON"},{18,"Wi-Fi Router","Electronics",12,1,"B","Normal","ON"},
 {19,"Dishwasher","Kitchen",1200,1,"B","Normal","ON"},{20,"Electric Vehicle Charger","Transport",3000,1,"B","Normal","ON"}
};

map<string, UserData> users;          // loaded per-user data (cache of data/users/<name>/...)
map<string, string>   sessions;       // token -> username
string DATA_DIR = "data";

// ------------------------------------------------------------------ helpers
string trim(const string &s){ size_t a=s.find_first_not_of(" \r\n\t"); if(a==string::npos)return ""; size_t b=s.find_last_not_of(" \r\n\t"); return s.substr(a,b-a+1); }
string lowerText(string s){ transform(s.begin(),s.end(),s.begin(),[](unsigned char c){return (char)tolower(c);}); return s; }
string currentDate(){ time_t now=time(nullptr); tm *t=localtime(&now); char b[16]; strftime(b,sizeof(b),"%Y-%m-%d",t); return b; }
bool validDate(const string &d){
 if(d.size()!=10||d[4]!='-'||d[7]!='-')return false;
 for(int i=0;i<10;i++)if(i!=4&&i!=7&&!isdigit((unsigned char)d[i]))return false;
 int y=atoi(d.substr(0,4).c_str()),m=atoi(d.substr(5,2).c_str()),day=atoi(d.substr(8,2).c_str());
 if(y<2000||m<1||m>12||day<1)return false;
 int days[]={31,28,31,30,31,30,31,31,30,31,30,31}; bool leap=(y%4==0&&(y%100!=0||y%400==0)); if(leap)days[1]=29;
 return day<=days[m-1];
}
string jsonEscape(const string &s){
 string o; char hex[8];
 for(unsigned char c:s){
  if(c=='"'||c=='\\'){o+='\\';o+=(char)c;}
  else if(c=='\n')o+="\\n"; else if(c=='\r')o+="\\r"; else if(c=='\t')o+="\\t";
  else if(c<32){snprintf(hex,sizeof(hex),"\\u%04x",c);o+=hex;}
  else o+=(char)c;
 }
 return o;
}
string urlDecode(const string &s){
 string o;
 for(size_t i=0;i<s.size();i++){
  if(s[i]=='+')o+=' ';
  else if(s[i]=='%'&&i+2<s.size()){ o+=(char)strtol(s.substr(i+1,2).c_str(),nullptr,16); i+=2; }
  else o+=s[i];
 }
 return o;
}
map<string,string> parseForm(const string &body){
 map<string,string> m; stringstream ss(body); string p;
 while(getline(ss,p,'&')){ size_t x=p.find('='); if(x!=string::npos)m[urlDecode(p.substr(0,x))]=urlDecode(p.substr(x+1)); }
 return m;
}
vector<string> splitCsv(const string &line,size_t n){ vector<string> v; stringstream ss(line); string x; while(getline(ss,x,','))v.push_back(trim(x)); while(v.size()<n)v.push_back(""); return v; }
bool cleanField(const string &s){ return s.find(',')==string::npos && s.find('\n')==string::npos && s.find('\r')==string::npos; }

// ------------------------------------------------------- password hashing (SHA-256)
struct Sha256 {
 static uint32_t rotr(uint32_t x,int n){ return (x>>n)|(x<<(32-n)); }
 static string hash(const string &msg){
  static const uint32_t k[64]={0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2};
  uint32_t h[8]={0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19};
  string m=msg; uint64_t bits=(uint64_t)m.size()*8; m+=(char)0x80; while(m.size()%64!=56)m+=(char)0;
  for(int i=7;i>=0;i--)m+=(char)((bits>>(i*8))&0xff);
  for(size_t off=0;off<m.size();off+=64){
   uint32_t w[64];
   for(int i=0;i<16;i++)w[i]=((uint32_t)(unsigned char)m[off+i*4]<<24)|((uint32_t)(unsigned char)m[off+i*4+1]<<16)|((uint32_t)(unsigned char)m[off+i*4+2]<<8)|(uint32_t)(unsigned char)m[off+i*4+3];
   for(int i=16;i<64;i++){ uint32_t s0=rotr(w[i-15],7)^rotr(w[i-15],18)^(w[i-15]>>3), s1=rotr(w[i-2],17)^rotr(w[i-2],19)^(w[i-2]>>10); w[i]=w[i-16]+s0+w[i-7]+s1; }
   uint32_t a=h[0],b=h[1],c=h[2],d=h[3],e=h[4],f=h[5],g=h[6],hh=h[7];
   for(int i=0;i<64;i++){
    uint32_t S1=rotr(e,6)^rotr(e,11)^rotr(e,25), ch=(e&f)^((~e)&g), t1=hh+S1+ch+k[i]+w[i];
    uint32_t S0=rotr(a,2)^rotr(a,13)^rotr(a,22), mj=(a&b)^(a&c)^(b&c), t2=S0+mj;
    hh=g;g=f;f=e;e=d+t1;d=c;c=b;b=a;a=t1+t2;
   }
   h[0]+=a;h[1]+=b;h[2]+=c;h[3]+=d;h[4]+=e;h[5]+=f;h[6]+=g;h[7]+=hh;
  }
  ostringstream o; for(int i=0;i<8;i++)o<<hex<<setw(8)<<setfill('0')<<h[i]; return o.str();
 }
};
string randomHex(int bytes){ random_device rd; ostringstream o; for(int i=0;i<bytes;i++)o<<hex<<setw(2)<<setfill('0')<<(rd()&0xff); return o.str(); }
string hashPassword(const string &salt,const string &pw){ string h=salt+pw; for(int i=0;i<2000;i++)h=Sha256::hash(h+salt+pw); return h; }

// ---------------------------------------------------------------- accounts
string usersFile(){ return DATA_DIR+"/users.csv"; }
string userDir(const string &u){ return DATA_DIR+"/users/"+u; }
bool validUsername(const string &u){
 if(u.size()<3||u.size()>30)return false;
 for(unsigned char c:u)if(!(isalnum(c)||c=='_'||c=='.'||c=='-'))return false;
 return true;
}
bool findUser(const string &u,string &salt,string &hash){
 ifstream f(usersFile()); string line; getline(f,line);
 while(getline(f,line)){ auto v=splitCsv(line,3); if(v[0]==u){salt=v[1];hash=v[2];return true;} }
 return false;
}
void addUser(const string &u,const string &salt,const string &hash){
 bool fresh=!fs::exists(usersFile())||fs::file_size(usersFile())==0;
 ofstream f(usersFile(),ios::app); if(fresh)f<<"username,salt,password_hash\n"; f<<u<<","<<salt<<","<<hash<<"\n";
}

// -------------------------------------------------------- per-user storage
void saveCustom(const string &u){
 ofstream f(userDir(u)+"/custom_appliances.csv"); f<<"name,category,watts,standby_watts,efficiency,priority,status\n";
 for(auto &a:users[u].custom)f<<a.name<<","<<a.category<<","<<a.watts<<","<<a.standby<<","<<a.efficiency<<","<<a.priority<<","<<a.status<<"\n";
}
string categoryOf(const string &u,const string &name){
 for(auto &a:DEFAULT_APPLIANCES)if(a.name==name)return a.category;
 for(auto &a:users[u].custom)if(a.name==name)return a.category;
 return "General";
}
void saveUsage(const string &u){
 ofstream f(userDir(u)+"/usage.csv"); f<<"id,date,name,hours,watts,category\n";
 for(auto &x:users[u].usages)f<<x.id<<","<<x.date<<","<<x.name<<","<<fixed<<setprecision(2)<<x.hours<<","<<x.watts<<","<<categoryOf(u,x.name)<<"\n";
}
void saveSettings(const string &u){ ofstream f(userDir(u)+"/settings.txt"); f<<(users[u].solar?"yes":"no"); }

UserData &loadUser(const string &u){
 if(users.count(u))return users[u];
 UserData d; string dir=userDir(u); fs::create_directories(dir);
 { ifstream f(dir+"/settings.txt"); string s; if(f>>s)d.solar=(s=="yes"); }
 { ifstream f(dir+"/custom_appliances.csv"); string line; getline(f,line);
   while(getline(f,line)){ if(trim(line).empty())continue; auto v=splitCsv(line,7);
     Appliance a; a.id=1000+(int)d.custom.size(); a.name=v[0]; a.category=v[1]; a.watts=atoi(v[2].c_str()); a.standby=atoi(v[3].c_str()); a.efficiency=v[4]; a.priority=v[5]; a.status=v[6].empty()?"ON":v[6];
     if(!a.name.empty()&&a.watts>0)d.custom.push_back(a); } }
 { ifstream f(dir+"/usage.csv"); string line; getline(f,line);
   while(getline(f,line)){ if(trim(line).empty())continue; auto v=splitCsv(line,6);
     Usage x; x.id=atoi(v[0].c_str()); x.date=v[1]; x.name=v[2]; x.hours=atof(v[3].c_str()); x.watts=atoi(v[4].c_str());
     if(!validDate(x.date)||x.name.empty()||x.watts<=0||x.hours<=0||x.hours>24)continue;
     x.daily=x.watts*x.hours/1000.0; d.usages.push_back(x); d.nextId=max(d.nextId,x.id+1); } }
 users[u]=d; return users[u];
}
vector<Appliance> catalogueFor(const string &u){ vector<Appliance> c=DEFAULT_APPLIANCES; for(auto &a:users[u].custom)c.push_back(a); return c; }

// ----------------------------------------------------------------- JSON state
string stateJson(const string &u,const string &selectedDate=""){
 UserData &d=loadUser(u);
 string day=validDate(selectedDate)?selectedDate:currentDate();
 double daily=0; int count=0; ostringstream o; o<<fixed<<setprecision(2);
 string latest=""; for(auto &x:d.usages)if(x.date>latest)latest=x.date;
 o<<"{\"user\":\""<<jsonEscape(u)<<"\",\"solar\":"<<(d.solar?"true":"false")<<",\"today\":\""<<day<<"\",\"date\":\""<<day<<"\",\"latestDate\":\""<<latest<<"\",\"totalEntries\":"<<d.usages.size()<<",\"tariff\":"<<TARIFF<<",\"catalogue\":[";
 auto cat=catalogueFor(u);
 for(size_t i=0;i<cat.size();i++){ if(i)o<<","; auto &a=cat[i];
  o<<"{\"id\":"<<a.id<<",\"name\":\""<<jsonEscape(a.name)<<"\",\"category\":\""<<jsonEscape(a.category)<<"\",\"watts\":"<<a.watts<<",\"standby\":"<<a.standby<<",\"efficiency\":\""<<jsonEscape(a.efficiency)<<"\",\"priority\":\""<<jsonEscape(a.priority)<<"\",\"status\":\""<<jsonEscape(a.status)<<"\",\"custom\":"<<(a.id>=1000?"true":"false")<<"}"; }
 o<<"],\"entries\":["; bool first=true;
 for(auto &x:d.usages)if(x.date==day){ if(!first)o<<","; first=false; count++; daily+=x.daily;
  o<<"{\"id\":"<<x.id<<",\"date\":\""<<x.date<<"\",\"name\":\""<<jsonEscape(x.name)<<"\",\"hours\":"<<x.hours<<",\"watts\":"<<x.watts<<",\"daily\":"<<x.daily<<",\"cost\":"<<x.daily*TARIFF<<"}"; }
 double solarUnits=d.solar?daily*0.60:0.0, grid=max(0.0,daily-solarUnits), cost=grid*TARIFF, projUnits=daily*30.0, projBill=cost*30.0, savings=solarUnits*TARIFF;
 o<<"],\"summary\":{\"daily\":"<<daily<<",\"count\":"<<count<<",\"monthly\":"<<projUnits<<",\"solarGeneration\":"<<solarUnits<<",\"solarUsed\":"<<solarUnits<<",\"solarUnits\":"<<solarUnits<<",\"grid\":"<<grid<<",\"bill\":"<<cost<<",\"projectedUnits\":"<<projUnits<<",\"projectedBill\":"<<projBill<<",\"savings\":"<<savings<<",\"peakHours\":0,\"monthPeakHours\":0,\"dayUnits\":"<<daily<<",\"nightUnits\":0,\"solarDay\":"<<solarUnits<<",\"gridDay\":"<<grid<<",\"solarNight\":0,\"gridNight\":0}}";
 return o.str();
}
string errJson(const string &m){ return "{\"error\":\""+jsonEscape(m)+"\"}"; }

// ------------------------------------------------------------------ WattBot
struct BotRule { vector<string> keys; string en, hi, hg; };
string botReply(string q,const string &lang){
 q=lowerText(q);
 static const vector<BotRule> rules={
  {{"outage","power cut","bijli gayi","light gayi","light cut","electricity gone"},
   "During a power cut, switch off non-essential appliances, keep fridge/freezer doors closed, save phone and inverter battery, and use a torch. Never touch fallen wires or attempt electrical repairs. When supply returns, reconnect appliances gradually.",
   "बिजली जाने पर गैर-ज़रूरी उपकरण बंद करें, फ्रिज का दरवाज़ा बंद रखें और फोन/इन्वर्टर की बैटरी बचाएँ। गिरे हुए तारों को न छुएँ और खुद मरम्मत न करें। बिजली आने पर उपकरण धीरे-धीरे चालू करें।",
   "Power cut mein non-essential appliances off kar do, fridge ka door closed rakho aur phone/inverter battery save karo. Fallen wires ko touch mat karna aur khud repair mat karna. Light aane par appliances gradually ON karna."},
  {{"inverter","battery"},
   "To conserve backup, switch off non-essential loads, avoid high-power appliances such as heaters and kettles, and do not overload the inverter. Follow the battery manufacturer's instructions.",
   "बैकअप बचाने के लिए गैर-ज़रूरी उपकरण बंद रखें, हीटर और केतली जैसे अधिक बिजली लेने वाले उपकरण न चलाएँ और इन्वर्टर पर अधिक लोड न डालें।",
   "Backup bachane ke liye non-essential appliances off rakho, heater/kettle jaise high-power devices avoid karo aur inverter overload mat karo."},
  {{"fridge","refrigerator"},
   "Keep refrigerator and freezer doors closed. A full freezer generally stays cold longer than an empty one. If food has become warm for an unsafe period, follow food-safety guidance and discard items when in doubt.",
   "फ्रिज और फ्रीज़र के दरवाज़े बंद रखें। खाना लंबे समय तक गर्म रहा हो तो खाद्य-सुरक्षा निर्देशों का पालन करें।",
   "Fridge/freezer ka door band rakho. Baar-baar mat kholo. Agar food kaafi der unsafe temperature par raha ho, food safety guidance follow karo."},
  {{"bill","cost","tariff"},
   "Estimated bill = grid units (kWh) × assumed tariff. This demo uses Rs 8 per unit; actual bills may include slab rates, fixed charges and taxes.",
   "अनुमानित बिल = ग्रिड यूनिट (kWh) × निर्धारित दर। इस डेमो में ₹8 प्रति यूनिट माना गया है। वास्तविक बिल में अन्य शुल्क भी हो सकते हैं।",
   "Estimated bill = grid units (kWh) × tariff. Is demo mein ₹8/unit assume kiya hai; actual bill mein fixed charges, slab rates aur taxes bhi ho sakte hain."},
  {{"solar"},
   "Solar Management estimates the solar and grid contribution. With solar ON, the model assumes 60% of your usage is met by solar. These are estimates, not live inverter readings.",
   "सोलर मैनेजमेंट सोलर और ग्रिड का अनुमानित योगदान दिखाता है। सोलर ON होने पर लगभग 60% खपत सोलर से मानी जाती है। ये वास्तविक इन्वर्टर रीडिंग नहीं हैं।",
   "Solar ON hone par demo 60% usage solar se assume karta hai. Ye estimates hain, live inverter readings nahi."},
  {{"add","appliance","device"},
   "Open My Appliances, choose an appliance, enter the date and approximate hours used, then tap Add usage. If it is missing, use 'Can't find your appliance? Add it yourself' to save a custom appliance to your account.",
   "My Appliances खोलें, उपकरण चुनें, तारीख और घंटे भरें और Add usage दबाएँ। सूची में न हो तो अपना उपकरण जोड़ने वाला विकल्प चुनें; वह आपके अकाउंट में सेव रहेगा।",
   "My Appliances kholo, appliance select karo, date aur hours bharo aur Add usage dabao. List mein nahi hai toh 'Add it yourself' option use karo; wo tumhare account mein save rahega."},
  {{"report"},
   "Open Complete Report to see your monthly energy, estimated bill, solar/grid split and appliance-wise schedule. Tap a report card or row for its calculation details.",
   "Complete Report में मासिक खपत, अनुमानित बिल, सोलर/ग्रिड योगदान और उपकरणों का विवरण देखें। अधिक जानकारी के लिए कार्ड या पंक्ति पर टैप करें।",
   "Complete Report kholo. Monthly units, estimated bill, solar/grid split aur appliance-wise details milengi. Calculation samajhne ke liye cards ya rows tap karo."},
  {{"reduce","save energy","saving","bachat"},
   "Use LED lighting, switch off idle devices, avoid standby loads, maintain AC filters, and shift deferrable heavy use away from peak hours where your tariff supports it.",
   "LED लाइट का उपयोग करें, खाली उपकरण बंद रखें, स्टैंडबाय बिजली कम करें और जहाँ संभव हो भारी उपयोग पीक समय से हटाएँ।",
   "LED use karo, idle devices off rakho, standby load kam karo aur possible ho toh heavy usage peak hours se shift karo."}
 };
 bool hi=(lang=="Hindi"), hg=(lang=="Hinglish");
 for(auto &r:rules)for(auto &k:r.keys)if(q.find(k)!=string::npos)return hi?r.hi:(hg?r.hg:r.en);
 if(hi)return "मुझे यह सवाल समझ नहीं आया। आप उपकरण, बिजली बिल, सोलर, ऊर्जा बचत, रिपोर्ट या बिजली कटौती के बारे में पूछ सकते हैं।";
 if(hg)return "Ye question abhi samajh nahi aaya. Appliances, bill, solar, energy saving, report ya power cut ke baare mein pooch kar dekho.";
 return "I couldn't match that question yet. Try asking about appliances, electricity bills, solar management, energy saving, reports or power cuts.";
}

// ------------------------------------------------------------------ HTTP
string readFile(const string &path){ ifstream f(path,ios::binary); if(!f)return "Not found"; stringstream b; b<<f.rdbuf(); return b.str(); }
void sendResponse(sock_t client,const string &status,const string &type,const string &body){
 string h="HTTP/1.1 "+status+"\r\nContent-Type: "+type+"\r\nContent-Length: "+to_string(body.size())+"\r\nConnection: close\r\nCache-Control: no-store\r\nAccess-Control-Allow-Origin: *\r\nAccess-Control-Allow-Methods: GET, POST, OPTIONS\r\nAccess-Control-Allow-Headers: Content-Type, X-Auth-Token\r\n\r\n";
 string all=h+body; size_t sent=0;
 while(sent<all.size()){ int n=(int)send(client,all.data()+sent,(int)(all.size()-sent),0); if(n<=0)break; sent+=(size_t)n; }
}
string headerValue(const string &headers,const string &name){
 stringstream ss(headers); string line; string key=lowerText(name)+":";
 while(getline(ss,line)){ string low=lowerText(line); if(low.compare(0,key.size(),key)==0)return trim(line.substr(key.size())); }
 return "";
}
const string JSON="application/json";

// Finds the project folder (the one that contains templates/index.html) so the
// program works no matter which folder it is started from.
bool locateProject(const char *argv0){
 vector<fs::path> tries={fs::current_path()};
 try{ fs::path exe=fs::absolute(argv0).parent_path(); tries.push_back(exe); tries.push_back(exe.parent_path()); }catch(...){}
 for(auto &p:tries) if(fs::exists(p/"templates"/"index.html")){ fs::current_path(p); return true; }
 return false;
}


// Opens the website in the default browser (Windows API / direct program launch, no shell).
void openBrowser(const string &url){
#ifdef _WIN32
 ShellExecuteA(nullptr,"open",url.c_str(),nullptr,nullptr,SW_SHOWNORMAL);
#else
 pid_t pid=fork();
 if(pid==0){
#ifdef __APPLE__
  execlp("open","open",url.c_str(),(char*)nullptr);
#else
  execlp("xdg-open","xdg-open",url.c_str(),(char*)nullptr);
#endif
  _exit(0);
 }
 if(pid>0)signal(SIGCHLD,SIG_IGN);
#endif
}

int main(int argc,char **argv){
#ifdef _WIN32
 WSADATA wsa; if(WSAStartup(MAKEWORD(2,2),&wsa)!=0){cerr<<"Could not start Windows networking.\n";return 1;}
#endif
 if(!locateProject(argv[0])){ cerr<<"Could not find templates/index.html. Keep main.cpp, templates and data together in one folder.\n"; return 1; }
 fs::create_directories(DATA_DIR+"/users");

 sock_t server=BAD_SOCK; int port=0;
 for(int candidate=8081;candidate<=8190;++candidate){
  sock_t fd=socket(AF_INET,SOCK_STREAM,0); if(fd==BAD_SOCK)continue;
#ifndef _WIN32
  int opt=1; setsockopt(fd,SOL_SOCKET,SO_REUSEADDR,(const char*)&opt,sizeof(opt));
#endif
  sockaddr_in addr{}; addr.sin_family=AF_INET; addr.sin_addr.s_addr=htonl(INADDR_ANY); addr.sin_port=htons((unsigned short)candidate);
  if(::bind(fd,(sockaddr*)&addr,sizeof(addr))==0&&listen(fd,16)==0){server=fd;port=candidate;break;}
  CLOSESOCK(fd);
 }
 if(server==BAD_SOCK){cerr<<"Could not start server: ports 8081-8190 are all in use. Close an older copy and try again.\n";return 1;}
 cout<<"Home Energy C++ server running at http://localhost:"<<port<<endl;
 cout<<"Opening your browser... Keep this window running. Press Ctrl+C to stop."<<endl;
 bool noBrowser=false; for(int i=1;i<argc;i++)if(string(argv[i])=="--no-browser")noBrowser=true;
 if(!noBrowser)openBrowser("http://localhost:"+to_string(port));

 while(true){
  sock_t client=accept(server,nullptr,nullptr); if(client==BAD_SOCK)continue;
#ifdef _WIN32
  DWORD tv=8000; setsockopt(client,SOL_SOCKET,SO_RCVTIMEO,(const char*)&tv,sizeof(tv)); setsockopt(client,SOL_SOCKET,SO_SNDTIMEO,(const char*)&tv,sizeof(tv));
#else
  timeval tv{}; tv.tv_sec=8; setsockopt(client,SOL_SOCKET,SO_RCVTIMEO,&tv,sizeof(tv)); setsockopt(client,SOL_SOCKET,SO_SNDTIMEO,&tv,sizeof(tv));
#endif
  string req; char buf[4096]; int n; size_t headerEnd=string::npos, contentLength=0;
  while((n=(int)recv(client,buf,sizeof(buf),0))>0){
   req.append(buf,(size_t)n); headerEnd=req.find("\r\n\r\n");
   if(headerEnd!=string::npos){ string cl=headerValue(req.substr(0,headerEnd),"content-length"); contentLength=cl.empty()?0:(size_t)strtoull(cl.c_str(),nullptr,10); if(req.size()>=headerEnd+4+contentLength)break; }
  }
  if(headerEnd==string::npos){sendResponse(client,"400 Bad Request","text/plain","Incomplete HTTP request");CLOSESOCK(client);continue;}
  string head=req.substr(0,headerEnd), body=req.substr(headerEnd+4,contentLength);
  stringstream hs(head); string method,path; hs>>method>>path;
  string route=path.substr(0,path.find('?'));
  string token=headerValue(head,"x-auth-token");

  try{
   if(method=="OPTIONS"){ sendResponse(client,"204 No Content","text/plain",""); }
   else if(method=="GET"&&route=="/"){ sendResponse(client,"200 OK","text/html; charset=utf-8",readFile("templates/index.html")); }
   else if(method=="GET"&&route=="/api/health"){ sendResponse(client,"200 OK",JSON,"{\"ok\":true,\"port\":"+to_string(port)+"}"); }
   else if(method=="POST"&&route=="/api/bot"){ auto m=parseForm(body); sendResponse(client,"200 OK",JSON,"{\"reply\":\""+jsonEscape(botReply(m["question"],m["lang"]))+"\"}"); }
   else if(method=="POST"&&route=="/api/register"){
    auto m=parseForm(body); string u=lowerText(trim(m["username"])), pw=m["password"]; string salt,hash;
    if(!validUsername(u)) sendResponse(client,"400 Bad Request",JSON,errJson("Username must be 3-30 characters: letters, numbers, dot, dash or underscore."));
    else if(pw.size()<4) sendResponse(client,"400 Bad Request",JSON,errJson("Password must be at least 4 characters."));
    else if(findUser(u,salt,hash)) sendResponse(client,"409 Conflict",JSON,errJson("That username is already taken. Please log in or choose another."));
    else{
     salt=randomHex(8); addUser(u,salt,hashPassword(salt,pw));
     UserData &d=loadUser(u); d.solar=(m["solar"]=="yes"); saveSettings(u); saveCustom(u); saveUsage(u);
     string t=randomHex(16); sessions[t]=u;
     sendResponse(client,"200 OK",JSON,"{\"token\":\""+t+"\",\"user\":\""+jsonEscape(u)+"\"}");
    }
   }
   else if(method=="POST"&&route=="/api/login"){
    auto m=parseForm(body); string u=lowerText(trim(m["username"])), pw=m["password"], salt,hash;
    if(!findUser(u,salt,hash)||hashPassword(salt,pw)!=hash) sendResponse(client,"401 Unauthorized",JSON,errJson("Wrong username or password."));
    else{ loadUser(u); string t=randomHex(16); sessions[t]=u; sendResponse(client,"200 OK",JSON,"{\"token\":\""+t+"\",\"user\":\""+jsonEscape(u)+"\"}"); }
   }
   else if(method=="POST"&&route=="/api/logout"){ sessions.erase(token); sendResponse(client,"200 OK",JSON,"{\"ok\":true}"); }
   else if(route.rfind("/api/",0)==0){
    // Everything below needs a logged-in user.
    auto it=sessions.find(token);
    if(it==sessions.end()){ sendResponse(client,"401 Unauthorized",JSON,errJson("Please log in.")); }
    else{
     string u=it->second; UserData &d=loadUser(u);
     if(method=="GET"&&route=="/api/state"){
      string date; size_t q=path.find("date="); if(q!=string::npos)date=path.substr(q+5,10);
      sendResponse(client,"200 OK",JSON,stateJson(u,date));
     }
     else if(method=="POST"&&route=="/api/setup"){ auto m=parseForm(body); d.solar=(m["solar"]=="yes"); saveSettings(u); sendResponse(client,"200 OK",JSON,stateJson(u,m["date"])); }
     else if(method=="POST"&&route=="/api/add"){
      auto m=parseForm(body); string name=m["name"], date=m["date"].empty()?currentDate():m["date"]; double hours=atof(m["hours"].c_str()); int watts=0;
      for(auto &a:catalogueFor(u))if(a.name==name)watts=a.watts;
      if(!watts||!validDate(date)||hours<=0||hours>24) sendResponse(client,"400 Bad Request",JSON,errJson("Choose an appliance, date and valid usage hours (0-24)."));
      else{ Usage x; x.id=d.nextId++; x.date=date; x.name=name; x.hours=hours; x.watts=watts; x.daily=watts*hours/1000.0; d.usages.push_back(x); saveUsage(u); sendResponse(client,"200 OK",JSON,stateJson(u,date)); }
     }
     else if(method=="POST"&&route=="/api/custom-appliance"){
      auto m=parseForm(body); Appliance a; a.id=1000+(int)d.custom.size(); a.name=trim(m["name"]); a.category=trim(m["category"]); a.watts=atoi(m["watts"].c_str()); a.standby=atoi(m["standby"].c_str());
      a.efficiency=trim(m["efficiency"]); a.priority=trim(m["priority"]); a.status=trim(m["status"]); if(a.status.empty())a.status="ON";
      bool dup=false; for(auto &x:catalogueFor(u))if(lowerText(x.name)==lowerText(a.name))dup=true;
      if(a.name.empty()||a.category.empty()||a.watts<=0||a.standby<0||!cleanField(a.name)||!cleanField(a.category)||!cleanField(a.efficiency)||!cleanField(a.priority)||dup)
       sendResponse(client,"400 Bad Request",JSON,errJson("Enter valid details. The appliance name must be new (no commas) and power must be positive."));
      else{ d.custom.push_back(a); saveCustom(u); sendResponse(client,"200 OK",JSON,stateJson(u,m["date"])); }
     }
     else if(method=="POST"&&route=="/api/delete"){
      auto m=parseForm(body); int id=atoi(m["id"].c_str());
      d.usages.erase(remove_if(d.usages.begin(),d.usages.end(),[&](const Usage &x){return x.id==id;}),d.usages.end());
      saveUsage(u); sendResponse(client,"200 OK",JSON,stateJson(u,m["date"]));
     }
     else if(method=="POST"&&route=="/api/clear"){ auto m=parseForm(body); d.usages.clear(); saveUsage(u); sendResponse(client,"200 OK",JSON,stateJson(u,m["date"])); }
     else sendResponse(client,"404 Not Found",JSON,errJson("Unknown request."));
    }
   }
   else sendResponse(client,"404 Not Found","text/plain","Not found");
  }catch(const exception &e){ sendResponse(client,"500 Internal Server Error",JSON,errJson(string("Server error: ")+e.what())); }
  CLOSESOCK(client);
 }
 return 0;
}
