HOME ENERGY ANALYTICS & BUDGET ADVISOR
C++17 backend + HTML/CSS/JavaScript frontend. No extra libraries needed.

EASIEST WAY: VS CODE (Windows / Mac / Linux)
1. File > Open Folder > choose this home_energy_cpp folder.
2. Install the "C/C++" extension if VS Code asks.
3. Press F5 (Run and Debug > "Run Home Energy Analytics").
   It builds the project and the website opens in your browser automatically.
4. Press the red Stop button to stop.

WITHOUT VS CODE
Compile main.cpp once with any C++17 compiler, then start the program:
   Mac / Linux / Termux :  clang++ -std=c++17 main.cpp -o home_energy
   Windows (MinGW)      :  g++ -std=c++17 main.cpp -o home_energy.exe -lws2_32
Start home_energy; your browser opens the website by itself
(http://localhost:8081, or the next free port up to 8190).
To stop it opening the browser, start with:  home_energy --no-browser
Keep the program running while you use the website.

LOGIN / ACCOUNTS
- First time: tap "Create account", choose a username and password.
- After that: just "Log in". Use the profile icon (top right) > Logout to sign out.
- Every account has its own appliances, usage entries and solar setting, so
  everything you add is still there after you log out and log in again,
  and even after you restart the program.
- Passwords are stored as salted hashes in data/users.csv (never in plain text).

APPLIANCES
- 20 common appliances (AC, fan, fridge, TV, geyser...) are built in for every account.
- "Can't find your appliance? Add it yourself" saves a custom appliance to YOUR account.

WHERE DATA IS SAVED (created automatically in the data folder)
data/users.csv                         usernames + hashed passwords
data/users/<name>/usage.csv            that user's usage entries
data/users/<name>/custom_appliances.csv  that user's own appliances
data/users/<name>/settings.txt         that user's solar setting
To wipe everything, stop the program and delete data/users and data/users.csv.

NOTES
- Example tariff: Rs 8 per unit (change TARIFF in main.cpp).
- Monthly figures are projections from the selected day's usage; solar and bill
  values are estimates, not meter readings.
- main.cpp, the templates folder and the data folder must stay together.
